﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElectricityUsageCalculator
{
    public partial class Form1 : Form
    {
        //Set Variables
        decimal DishwasherTime = 0;
        decimal DishwasherRate = 0.16m;
        decimal ElectricCookerTime = 0;
        decimal ElectricCookerRate = 0.95m;
        decimal HooverTime = 0;
        decimal HooverRate = 0.3m;
        decimal count = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Loop Variables and Validation
            listBox1.Items.Clear();
            decimal DishwasherTotal = 0;
            decimal ElectricCookerTotal = 0;
            decimal HooverTotal = 0;

            bool HasErrors = false;
            try
            {
                DishwasherTime = decimal.Parse(textBox1.Text);
                ElectricCookerTime = decimal.Parse(textBox2.Text);
                HooverTime = decimal.Parse(textBox3.Text);
            }
            catch
            {
                HasErrors = true;
            }
            if ((HasErrors == true) || ((decimal.Parse(textBox1.Text) < 0) ||
                (decimal.Parse(textBox2.Text) < 0) || (decimal.Parse(textBox3.Text) < 0)))
            {
                MessageBox.Show("Incorrect user input");
            }
            else
            {
                //Dishwasher Loop
                count = 0;
                do
                {
                    if (DishwasherTime > 0)
                    {
                        DishwasherTotal = DishwasherTotal + DishwasherRate;
                        listBox1.Items.Add("Dishwasher usage of " + DishwasherTime +
                            " hour(s) Costs " + DishwasherTotal + " €");
                        count++;
                    }
                    else
                    {
                        listBox1.Items.Add("Dishwasher usage of " + DishwasherTime + " hours Costs " + "0" + " €");
                    }
                }
                while (count < DishwasherTime);

                //Electric Cooker Loop
                count = 0;
                do
                {
                    if (ElectricCookerTime > 0)
                    {
                        ElectricCookerTotal = ElectricCookerTotal + ElectricCookerRate;
                        listBox1.Items.Add("Electric Cooker usage of " + ElectricCookerTime +
                            " hour(s) Costs " + ElectricCookerTotal + " €");
                        count++;
                    }
                    else
                    {
                        listBox1.Items.Add("Electric Cooker usage of " + ElectricCookerTime + " hours Costs " + "0" + " €");
                    }
                }
                while (count < ElectricCookerTime);


                //Hoover Loop
                count = 0;
                do
                {
                    if (HooverTime > 0)
                    {
                        HooverTotal = HooverTotal + HooverRate;
                        listBox1.Items.Add("Hoover usage of " + HooverTime +
                            " hour(s) Costs " + HooverTotal + " €");
                        count++;
                    }
                    else
                    {
                        listBox1.Items.Add("Hoover usage of " + HooverTime + " hours Costs " + "0" + " €");
                    }
                }
                while (count < HooverTime) ;

                //Total cost
                listBox1.Items.Add("");
                listBox1.Items.Add("Total cost is :" + (DishwasherTotal + 
                    ElectricCookerTotal + HooverTotal) + " €");
            }
        }
    }
}

