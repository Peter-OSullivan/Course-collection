﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LowestNumberArray
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listBox1.Items.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //create array
            int[] numbers = new int[5];
            bool isValidUserInput = true;

            try
            {
                numbers[0] = int.Parse(textBox1.Text); textBox1.SelectAll();
                numbers[1] = int.Parse(textBox2.Text); textBox2.SelectAll();
                numbers[2] = int.Parse(textBox3.Text); textBox3.SelectAll();
                numbers[3] = int.Parse(textBox4.Text); textBox4.SelectAll();
                numbers[4] = int.Parse(textBox5.Text); textBox5.SelectAll();
            }
            catch
            {
                isValidUserInput = false;
            }
            if (isValidUserInput)
            {
                //search for Lowest number
                int lowestNumber = numbers[0];
                foreach(int number in numbers)
                {
                    if (number<lowestNumber)
                    {
                        //lowestNumber becomes the new lowestnumber
                        lowestNumber = number;
                    }
                }
                listBox1.Items.Clear();
                listBox1.Items.Add("The lowest number is " + lowestNumber);
                textBox1.Focus();
                textBox1.SelectAll();
            }
            else
            {
                MessageBox.Show("Invalid user input");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox1.Focus();


            }


        }
    }
}
