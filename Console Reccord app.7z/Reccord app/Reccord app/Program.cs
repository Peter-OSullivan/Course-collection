﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reccord_app
{
    class Program
    {
        static void Main(string[] args)
        {
            Double RaceTime = 0;
            bool userWantsToExit = false;

            Console.WriteLine("Please enter Current Record : ");
            Double Record = double.Parse(Console.ReadLine());
            Console.WriteLine("\n");

            while (!userWantsToExit)
            {
                try
                {
                    Console.WriteLine("Enter Current Race Time : ");
                    RaceTime = Double.Parse(Console.ReadLine());

                    if (RaceTime > Record)
                    {
                        Console.WriteLine("\nSorry Your time was not a Record.");
                    }
                    else if (RaceTime < Record && RaceTime != 0)
                    {
                        Record = RaceTime;
                        Console.WriteLine("\nCongratulations ! your Race Time is a new Record !");
                        new Data { Record = RaceTime };
                        Console.WriteLine("\nNew Record = " + Record);
                    }

                    else if (Record == RaceTime)
                    {
                        Console.WriteLine("\nYour Time Equals the current Record ");
                    }
                    if (Console.ReadLine().ToLower() == "exit")
                        userWantsToExit = true;
                }
                catch
                {

                }

            }



        }

    }
}
