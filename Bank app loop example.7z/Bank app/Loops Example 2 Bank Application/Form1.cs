﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loops_Example_2_Bank_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int NumberOfMonths = 0;
            int StartingBalance = 0;
            int InterestPerMonth = 2;
            bool HasErrors = false;

            try
            {
                StartingBalance = int.Parse(textBox1.Text);
                NumberOfMonths = int.Parse(textBox2.Text);
            }
            catch
            {
                HasErrors = true;
            }

            if(HasErrors)
            {
                MessageBox.Show("Error reading user input ");
            }   
            else
            {
                int count = 1;

                while(count <= NumberOfMonths)
                {
                    StartingBalance = StartingBalance + InterestPerMonth;

                    if (count == 1)
                    {
                        listBox1.Items.Add("The balance after " + count
                            + " month is : €" + StartingBalance);
                    }
                    else
                    {
                        listBox1.Items.Add("The balance after " + count
                           + " months is : €" + StartingBalance);
                    }


                    count++;
                }

                listBox1.Items.Add("The total balance for the investment is " 
                    + StartingBalance);
            }
        }

        private void button2_Click(object sender, EventArgs e)
            {
            listBox1.Items.Clear();
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            }
        }
}
