﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oop_09_08_16
{
    class SavingsAccount : BankAccount
    {
        #region constructor
        public SavingsAccount(decimal InterestRate)
        {
            this.InterestRate = InterestRate;
        }
        #endregion
        #region Properties
        public decimal InterestRate
        {
            get;

        }

        #endregion
        #region Methods

        public override string DisplayBankAccountInformation()
        {
            string AccountInfo = "Savings Account Number is : " + AccountID + " Account Balance is €" + Balance;

            return AccountInfo;
        }

        #endregion
    }
}
