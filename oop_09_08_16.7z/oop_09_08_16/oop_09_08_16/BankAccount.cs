﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oop_09_08_16
{
    public abstract class BankAccount
    {
        #region Properties
        public string FirstnameName { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }
        public string Email { get; set; }
        public string LastName { get; set; }

        //readonly properties for balance and accountnumber
        private decimal balance;
        public decimal Balance { get; }
        public string AccountID { get; }
        #endregion


        #region Constructors
        public BankAccount()
        {

        }

        public BankAccount(string FirstnameName, string LastName, int Age, string Email)
        {
            //set start balance
            Balance = 0;


            //set account number
            AccountID = "xxxx";
        }
        #endregion


        #region methods
        public bool SaveToDAtaBase()
        {


            return true;
        }
        public virtual string DisplayBankAccountInformation()
        {
            string AccountInfo = "Account Number is : " + AccountID + " Account Balance is €" + Balance;

            return AccountInfo;
        }

        public void WithdrawAmount(decimal AmountToWithdraw)
        {
            balance = balance - AmountToWithdraw;
        }
        public void DepositAmount(decimal AmountToDeposit)
        {
            balance = balance + AmountToDeposit;
        }

        #endregion
    }
}
