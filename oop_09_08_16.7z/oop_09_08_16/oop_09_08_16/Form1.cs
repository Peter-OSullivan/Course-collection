﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace oop_09_08_16
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listBox1.Items.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateAccount(AccountTypes.CurrentAccount);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CreateAccount(AccountTypes.SavingsAccount);
        }

        public void CreateAccount(AccountTypes type)
        {
            bool HasErrors = false;
            string FirstName = textBox1.Text;
            string LastName = textBox2.Text;
            int Age = int.Parse(textBox3.Text);
            string Email = textBox4.Text;
            //Validation
            //Check fieds for empty or invalid data and create only if valid
            int count1 = 0;
            int count2 = 0;
            int count3 = 0;
            try
            {
                if (textBox1.Text == null || textBox2.Text == null || textBox3.Text == null || textBox4.Text == null)
                {
                    HasErrors = true;
                    textBox1.SelectAll();
                    MessageBox.Show("Required field(s) are blank");
                }
                if (textBox1.Text.Any(char.IsDigit) || textBox2.Text.Any(char.IsDigit))
                {
                    HasErrors = true;
                    count1=1;
                }
                if (textBox3.Text.Any(char.IsLetter))
                {
                    HasErrors = true;
                    count2=2;
                } 
                if (!(textBox4.Text.Contains("@")))
                {
                    HasErrors = true;
                    count3=3;
                }
            }
            catch
            {
                HasErrors = true;
            }
            if (HasErrors)
            {
                if (count1==1)
                {
                    textBox1.SelectAll();
                    MessageBox.Show("Incorrect name entered");
                }
                else if (count2 == 2)
                {
                    textBox3.SelectAll();
                    MessageBox.Show("Invalid age");
                }
                else if (count3 == 3)
                {
                    textBox4.SelectAll();
                    MessageBox.Show("Please enter Correct Email address");
                }
            }
            else
            {
                //set up our starting balance
                BankAccount account;
                switch (type)
                {
                    case AccountTypes.CurrentAccount:
                        account = new CurrentAccount(FirstName, LastName, Age, Email);
                        break;

                    case AccountTypes.SavingsAccount:
                        account = new SavingsAccount(0.2m);
                        break;

                    default:
                        account = new CurrentAccount(FirstName, LastName, Age, Email);
                        break;

                }
                //save to database
                account.SaveToDAtaBase();

                listBox1.Items.Add("Account Created : your starting balance is " + account.Balance);
            }
        }
    }
}
