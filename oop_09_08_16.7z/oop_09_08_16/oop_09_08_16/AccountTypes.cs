﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oop_09_08_16
{
    public enum AccountTypes
    {
        CurrentAccount,
        SavingsAccount
    }
}
