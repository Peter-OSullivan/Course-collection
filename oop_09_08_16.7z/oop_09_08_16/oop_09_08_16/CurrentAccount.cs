﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oop_09_08_16
{
    public class CurrentAccount : BankAccount
    {
        #region Constructor

        public CurrentAccount(string FirstnameName, string LastName, int Age, string Email)
            : base(FirstnameName, LastName, Age, Email)
        {
            this.FirstnameName = FirstnameName;
            this.LastName = LastName;
            this.Age = Age;
            this.Email = Email;
        }

        #endregion

        #region Properties
        public decimal OverdraftRate
        {
            get;

        }
        #endregion

        #region Methods

        public override string DisplayBankAccountInformation()
        {
            string AccountInfo = "Current Account Number is : " + AccountID + " Account Balance is €" + Balance;

            return AccountInfo;
        }

        #endregion
    }
}
