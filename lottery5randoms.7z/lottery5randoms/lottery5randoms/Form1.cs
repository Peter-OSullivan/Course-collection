﻿using System;
using System.Linq;
using System.Windows.Forms;
namespace lottery5randoms
{
    public partial class Form1 : Form
    {
        //Main variables
        int[] myArray = new int[5];
        //int[] mySecondArray = new int[5];
        public Form1()
        {
            InitializeComponent();
            listBox1.Items.Clear();

        }

        public void checkArray()
        {
            bool hasErrors = false;

            try
            {
                // mySecondArray[0] = 
                int.Parse(textBox6.Text);
                // mySecondArray[1] = 
                int.Parse(textBox7.Text);
                // mySecondArray[2] = 
                int.Parse(textBox8.Text);
                // mySecondArray[3] = 
                int.Parse(textBox9.Text);
                // mySecondArray[4] = 
                int.Parse(textBox10.Text);
            }
            catch
            {
                hasErrors = true;
            }
            if (hasErrors == true)
            {
                MessageBox.Show("Incorrect input");

            }
            else
            {
                //Compare user numbers in second array to random numbers in first array
                int count = 0;
                if (myArray.Contains(int.Parse(textBox6.Text)))
                {
                    count++;
                }
                if (myArray.Contains(int.Parse(textBox7.Text)))
                {
                    count++;
                }
                if (myArray.Contains(int.Parse(textBox8.Text)))
                {
                    count++;
                }
                if (myArray.Contains(int.Parse(textBox9.Text)))
                {
                    count++;
                }
                if (myArray.Contains(int.Parse(textBox10.Text)))
                {
                    count++;
                }
                listBox1.Items.Add(count + "Matches");
            }
            return;
        }

        public int GenerateRandomNumbers()
        {
            //Generate random numbers in range 1-50 inclusive
            Random randomNumbers = new Random();
            int randomNumber = randomNumbers.Next(1, 51);

            // populate the array with 5 random values and show numbers
            try
            {

            for (int i = 0; i < 5; i++)   
            {
                randomNumber = randomNumbers.Next(1, 51);
                if (!myArray.Contains(randomNumber))
                    myArray[i] = randomNumber;
                else
                    i=0;
                string RandomNumbers = Convert.ToString(randomNumber);

                myArray[i] = randomNumber;
            }
            }
            catch
            {
                MessageBox.Show("Woops");
            }
            textBox1.Text = myArray[0].ToString();
            textBox2.Text = myArray[1].ToString();
            textBox3.Text = myArray[2].ToString();
            textBox4.Text = myArray[3].ToString();
            textBox5.Text = myArray[4].ToString();
            return (randomNumber);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Call random numbers method with output to textboxes
            GenerateRandomNumbers();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            checkArray();
        }
    }
}
