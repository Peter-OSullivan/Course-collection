﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyArray
{
    public partial class Form1 : Form
    {
        //Create Array

        int[] MyArray = new int[5];
        int Highest = 0;
        int Lowest = int.MaxValue;

        public Form1()
        {
            InitializeComponent();
			/*
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox4.Text = string.Empty;
            textBox5.Text = string.Empty;
			 * */
        }
		private bool calculate()
		{
			bool HasErrors = false;

			//Validate input
			try
			{
				MyArray[0] = int.Parse(textBox1.Text);
				MyArray[1] = int.Parse(textBox2.Text);
				MyArray[2] = int.Parse(textBox3.Text);
				MyArray[3] = int.Parse(textBox4.Text);
				MyArray[4] = int.Parse(textBox5.Text);
			}
			catch
			{
				HasErrors = true;
			}
			if (HasErrors == true)
			{
				MessageBox.Show("Invalid user input.");
			}
			else
			{
				foreach (int Number in MyArray)
				{
					if (Number < 1 || Number > 100)
					{
						MessageBox.Show("Number out of range.");
						HasErrors = true;
						break;
					}
				}

				// #2 - duplicates
				// how to ... each number much be checked against all the preceeding numbers
				// from 1 up .. since 0 has no before time
				// after the before time ... 1 = 0?  2 = 1?  2 = 0?
				// methodology ... for (1 to 4) {  inside loop for (0 to outer loop - 1) { test } }
				if (HasErrors == false)
				{
					for (int outerIndex = 1; outerIndex <= 4; outerIndex++)
					{
						for (int innerIndex = 0; innerIndex < outerIndex; innerIndex++)
						{
							if (MyArray[outerIndex] == MyArray[innerIndex])
							{
								MessageBox.Show("Duplicate numbers in array.");
								HasErrors = true;
								break;
							}
						}
					}
				}
			}
			return HasErrors;
		}

        private void button1_Click(object sender, EventArgs e)
        {
			if (calculate() == false)
			{
				foreach (int Number in MyArray)
				{
					if (Number > Highest)
					{
						Highest = Number;
					}
				}
				//Highest number
				listBox1.Items.Add("The Highest Number is : " + Highest);
			}
        }

        private void button2_Click(object sender, EventArgs e)
        {
			if (calculate() == false)
			{
				foreach (int Number in MyArray)
				{
					if (Number < Lowest)
					{
						Lowest = Number;
					}
				}
				//Lowest number
				listBox1.Items.Add("The Lowest Number is : " + Lowest);
			}
        }

    }
}
