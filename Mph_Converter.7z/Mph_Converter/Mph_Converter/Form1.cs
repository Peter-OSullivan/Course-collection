﻿using System;
using System.Windows.Forms;

namespace Mph_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listBox1.Items.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //initial variables
            var kmph = 60;

            //loop calculations
            for (var count = 100; kmph <= count; kmph += 10)
            {
                var mph = (kmph * 0.6214);
                listBox1.Items.Add(kmph + " KMph is "+ mph + " Mph");
            }
        }
    }
}

